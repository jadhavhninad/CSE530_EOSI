sudo rmmod rbt530_drv
