#include <linux/ioctl.h>

#define IOCTL_SET_END _IOR('k',1, int)

