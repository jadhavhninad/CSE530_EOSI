1.To compile use :
make

(Note, even after passing the pthread flag, warnings are shown. Also for the kernel module, compiling for the first time shows warnings. After Recompiling warnings are not shown)

2. to initialize the tree driver, use
./init_rb.sh


3.to run the test user program run,
./rb_test 


4. TO remove the driver, run:
./exit_rb.sh
