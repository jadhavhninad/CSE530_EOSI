1. Use make
2. Copy the relevant*.ko files and led_spi_user.o file to the galileo board
3. Insert the modules.
4. Run the led_spi_user.o user program.

TEAM: 29
Ninad Jadhav - 1213245837
Mohsen Alamadi - 1213421376
